#include "ros/ros.h"
#include "std_msgs/String.h"
#include "visualization_msgs/MarkerArray.h"
#include <sstream>
#include <termios.h>
#include <Eigen/Dense>
#include "audi_projection/Key.h"
#include <iostream>
#include <tf/transform_listener.h>
#include <image_geometry/pinhole_camera_model.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv/cv.h>

#define BALL_TO_TIP 0.408
#define MEAN_NUMBER 10

using namespace Eigen;
ros::Publisher marker_pub;

bool measurement_is_active = false;
bool waiting = false;
Vector3d measure_p;
Vector3d mean_p;

size_t measurements_left = 0;
std::vector<std::vector<tf::Point> > list_of_polygons;
std::shared_ptr<tf::TransformListener> listener;
image_transport::Publisher im_pub;
image_geometry::PinholeCameraModel cam_model_;
CvFont font_;

void sendMarker(const Vector3d point){
    visualization_msgs::Marker marker;

    marker.header.frame_id = "/mocap";
    marker.header.stamp = ros::Time::now();

    marker.ns = "measure_p";
    marker.id = 0;

    marker.type = visualization_msgs::Marker::CUBE;

    marker.action = visualization_msgs::Marker::ADD;

    marker.pose.position.x = point(0);
    marker.pose.position.y = point(1);
    marker.pose.position.z = point(2);
    marker.pose.orientation.x = 0;
    marker.pose.orientation.y = 0;
    marker.pose.orientation.z = 0;
    marker.pose.orientation.w = 1.0;

    marker.scale.x = 0.05;
    marker.scale.y = 0.05;
    marker.scale.z = 0.05;

    marker.color.r = 0.0f;
    marker.color.g = 1.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;

    marker.lifetime = ros::Duration();

    marker_pub.publish(marker);

}

void marker_callback(const visualization_msgs::MarkerArray::ConstPtr& msg)
{
    std::cout << "Got marker..." << msg->markers[0].points.size() << std::endl;
    std::vector<Vector3d> all_p;
    //if(msg->markers.size() < 1) return;
    if(msg->markers[0].points.size() < 4)
	{
	std::cout << "Too less points for meas wand.." << std::endl;
	 return;
	}

    for(size_t i = 0; i < msg->markers[0].points.size(); i++){
        //std::cout << "Point: " << msg->markers[0].points[i].x <<"/" << msg->markers[0].points[i].y << "/" << msg->markers[0].points[i].z << std::endl;

        Vector3d point(-msg->markers[0].points[i].x,msg->markers[0].points[i].y,-msg->markers[0].points[i].z);
        if(std::isnan(point(0))){
            std::cout << "Point is nan...skipping..." << std::endl;
            return;
        }
        all_p.push_back(point);
    }
    Vector3d dir = (all_p[3] - all_p[0]).normalized();
    measure_p = all_p[0] + BALL_TO_TIP * dir;
    sendMarker(measure_p);

    // Got tip of wand

    if(!measurement_is_active){
        std::cout << "Measure point: " <<  measure_p(0) << "/" << measure_p(1) << "/" << measure_p(2) << std::endl;
        std::cout << "Points detected: " << msg->markers[0].points.size() << std::endl;
        std::cout << "----------------------------------------------" << std::endl;
    }else{
        if(measurements_left > 0){
            mean_p = mean_p + measure_p;
            measurements_left--;
        }
    }
}

void imageCb(const sensor_msgs::ImageConstPtr& image_msg,
             const sensor_msgs::CameraInfoConstPtr& info_msg){

    cv::Mat image;
    cv_bridge::CvImagePtr input_bridge;
    try {
        input_bridge = cv_bridge::toCvCopy(image_msg, sensor_msgs::image_encodings::BGR8);
        image = input_bridge->image;
    }
    catch (cv_bridge::Exception& ex){
        ROS_ERROR("[draw_frames] Failed to convert image");
        return;
    }

    cam_model_.fromCameraInfo(info_msg);

    tf::StampedTransform transform;
    try{
        ros::Time acquisition_time = info_msg->header.stamp;
        ros::Duration timeout(1.0 / 30);
        listener->waitForTransform("/world", cam_model_.tfFrame(),
                                   acquisition_time, timeout);
        listener->lookupTransform("/world", cam_model_.tfFrame(),
                                  ros::Time(0), transform);

        for(size_t i = 0; i < list_of_polygons.size(); i++){
            for(size_t k = 0; k < list_of_polygons.at(i).size(); k++){
                std::cout << "Project Point ..." << std::endl;

                tf::Point pt = transform * list_of_polygons.at(i).at(k);
                cv::Point3d pt_cv(pt.x(), pt.y(), pt.z());
                cv::Point2d uv;
                uv = cam_model_.project3dToPixel(pt_cv);

                static const int RADIUS = 3;
                cv::circle(image, uv, RADIUS, CV_RGB(255,0,0), -1);
                CvSize text_size;
                int baseline;
                std::string to_write = std::to_string(i*k);
                cvGetTextSize(to_write.c_str(), &font_, &text_size, &baseline);
                CvPoint origin = cvPoint(uv.x - text_size.width / 2,
                                         uv.y - RADIUS - baseline - 3);
                putText(image, to_write.c_str(), origin, cv::FONT_HERSHEY_SIMPLEX, 12, CV_RGB(255,0,0));
            }
        }

        im_pub.publish(input_bridge->toImageMsg());
    }
    catch (tf::TransformException ex){
        ROS_ERROR("%s",ex.what());
        ros::Duration(1.0).sleep();
    }


}

void key_callback(const audi_projection::Key::ConstPtr& msg){
    static std::vector<tf::Point> points;
    if(msg->code == audi_projection::Key::KEY_SPACE){
        std::cout << "Measurement started..." << std::endl;
        static Vector3d start_p;
        if(!measurement_is_active){
            measurement_is_active = true;
            // MEAN START POSITION
            measurements_left = MEAN_NUMBER;
            while(measurements_left > 0){
                ros::spinOnce();
                ros::Duration(0.005).sleep();
            }
            start_p = mean_p / MEAN_NUMBER;

            std::cout << "Save point: " <<  start_p(0) << "/" << start_p(1) << "/" << start_p(2) << std::endl;

            tf::Point pt;
            pt.setX(start_p[0]);
            pt.setY(start_p[1]);
            pt.setZ(start_p[2]);
            points.push_back(pt);

            measurement_is_active = false;
        }
    }else if (msg->code == audi_projection::Key::KEY_END){
        std::cout << "Submit points..." << std::endl;
        list_of_polygons.push_back(points);
        points.clear();
    }
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "audi_projection_node");
    ros::NodeHandle n;
    ros::Subscriber sub = n.subscribe("/cortex_marker_array", 1000, marker_callback);
    ros::Subscriber key_sub = n.subscribe("/keyboard/keyup", 1000, key_callback);
    marker_pub = n.advertise<visualization_msgs::Marker>("measure_point", 1);
    listener = std::shared_ptr<tf::TransformListener>(new tf::TransformListener());
    cvInitFont(&font_, CV_FONT_HERSHEY_SIMPLEX, 0.5, 0.5);

    image_transport::ImageTransport it_(n);
    image_transport::CameraSubscriber image_sub = it_.subscribeCamera("/image", 1, imageCb);
    im_pub =  it_.advertise("/augmented_image", 1);

    ros::Rate loop_rate(200);

    int count = 0;
    while (ros::ok())
    {
        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}
