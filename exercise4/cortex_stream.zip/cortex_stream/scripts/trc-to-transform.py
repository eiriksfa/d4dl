#!/usr/bin/env python
 #
 # A ROS interface for the Cortex Motion Capture System Network Stream
 #
 # Copyright 2011 by Daniel Maier, University of Freiburg
 # based on the robular implementation by Joerg Mueller
 # 
 # This program is free software: you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation, version 3.
 #
 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program.  If not, see <http://www.gnu.org/licenses/>.



import roslib; roslib.load_manifest('cortex_stream')
import rospy
import tf
import getopt,sys
import argparse
import numpy as np
import math
import ConfigParser, os
from visualization_msgs.msg import MarkerArray
from nav_msgs.msg import Odometry
from std_msgs.msg import String
from prop import Prop,Marker

class Tracker():
    def __init__(self):
        self.prop = Prop()
                
    def marker_callback(self, frame_id, markers, max_not_observed):
        ptG = []
        ptO = []
        for i in markers:
            pt = markers[i]
            if math.isnan(pt[0]) or math.isnan(pt[1]) or math.isnan(pt[2]):
                print "NaN found!"
                continue
            pos = self.prop.Markers[i].position[:]
            ptO.append( [pos[0],pos[1],pos[2],1] )
            ptG.append( [pt[0], pt[1], pt[2], 1] )
            
 	#self.prop.Markers: array of markers in prop file
	#pt0: position of observed markers in prop file
	#ptG: position of observed markers in data
	if len(ptO) != len(ptG):
	    rospy.logwarn("Matrix size don't match")
            sys.exit(0)
        if len(ptO) < 3 or len(ptO) < (len(self.prop.Markers) - max_not_observed):
            #rospy.logwarn("too few valid marker positions for pose estimation. skipping.")
            return

        # estimate pose of object
        x = np.matrix(ptO)[:,0:3].transpose()
        y = np.matrix(ptG)[:,0:3].transpose()
        mx = np.mean(x,1)
        my = np.mean(y,1)
        K = (y-my) * (x-mx).transpose()
        U,S,V = np.linalg.svd(K)
        SS = np.eye(3)
        if np.linalg.det(U) * np.linalg.det(V) < 0:
            SS[2,2] = -1.0
        else:
            SS[2,2] = 1.0
        R = U*SS*V
        T = my - R*mx
        tx = T[0]
        ty = T[1]
        tz = T[2]
        T = np.eye(4)
        T[0:3,0:3] = R
        T[0,3] = tx
        T[1,3] = ty
        T[2,3] = tz

        try:
            q = tf.transformations.quaternion_from_matrix(T)
        except Exception as e:
            rospy.logerr( "caught quat exception" )
            rospy.logerr( e )
            rospy.logerr( "transform was: " + str(T) )
        return (frame_id, tx, ty , tz, q)
    pass 

    def add_prop_from_file(self,file):
        if self.prop.parse_prop_file(file):
            print 'Using propfile ' + self.prop.Name
            rospy.loginfo( self.prop )
        else:
            rospy.logerr( "error adding prop from %s"%(file) )

if __name__=='__main__':
    myargs = rospy.myargv(sys.argv)

    if len(sys.argv) < 4 or len(sys.argv) > 5:
      print 'USAGE: python ' +  sys.argv[0] + ' file.trc model.prop outfile.csv [max unobserved markers (default 0)]\n'
      sys.exit()

    parser = argparse.ArgumentParser(description='Track Cortex rigid body from prop file(s).')
    parser.add_argument('file',metavar='FILENAME', type=file, nargs='?', help='filename')
    parser.add_argument('prop', metavar='PROPFILE', type=file, nargs='?', help='prop file(s)')
    parser.add_argument('outfile', metavar='OUTFILE', type=argparse.FileType('w'), nargs='?', help='prop file(s)')
    if len(sys.argv) == 5:
        parser.add_argument('max_unobserved', metavar='MAXUNOBSERVED', type=int, nargs='?', help='prop file(s)')
    
    myargs = myargs[1:]
    args = parser.parse_args(myargs)

    #Outfile
    outfile = args.outfile
    print 'Write to ' + outfile.name
    
    #TRC file
    tracker = Tracker()
    trcfile = args.file
    
    #add prop file
    tracker.add_prop_from_file(args.prop)
    lines = trcfile.readlines()

    #maximum unobserved markers
    if len(sys.argv) == 5:
        max_not_observed = args.max_unobserved
    else:
        max_not_observed = 0

    l = 1;
    num_markers = 0
    for l in range(0, len(lines)):
        tokens = lines[l].split('\t')
        if tokens[0] == 'Frame#': #header line
            num_markers = (len(tokens) - 3)
            if num_markers % 3 != 0:
                print 'Invalid format: Header line should contain marker names'
                sys.exit(0)
            num_markers = num_markers / 3
            print '#Markers = ' + str(num_markers)
            break

    frame_id = 1
    valid_transformations = 0
    for i in range(l + 3, len(lines)):
        tokens = lines[i].split('\t')
        if int(tokens[0]) == frame_id:
            markers = dict()
            for j in range(0, num_markers):
                try:
	            # trc files are in [mm], convert to [m]
                    x = 0.001*float(tokens[2 + j*3])
                    y = 0.001*float(tokens[2 + j*3 + 1])
                    z = 0.001*float(tokens[2 + j*3 + 2])
	            markers[j] = (x,y,z)
                except:
                    continue
            transform = tracker.marker_callback(frame_id, markers, max_not_observed)
            if transform != None:
              frame_id = transform[0]
              valid_transformations = valid_transformations + 1
              x = float(transform[1])
              y = float(transform[2])
              z = float(transform[3])
              T = transform[4]
              outfile.write(str(frame_id) + ' ' + str(x) + ' ' + str(y) + ' ' + str(z) + ' ' + str(T[0]) + ' '+ str(T[1]) + ' '+ str(T[2]) + ' '+ str(T[3]) + '\n')
            frame_id = frame_id + 1
       
    print str(100 * float(valid_transformations) / frame_id) + ' % valid transformations'	  
    sys.exit()
